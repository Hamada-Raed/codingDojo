var newName = document.querySelector("#name")
function changename(){
    newName.innerText = "Mohammad"
}

var img1 = document.getElementById("Spectial-img1") 
function remove1(){
    img1.remove()
}

var img2 = document.getElementById("Spectial-img2")
function remove2(){
    img2.remove()
}